// -------------------------------------------------------------------------

/**
 * This class contains static methods that implementing sorting of an array of
 * numbers using different sort algorithms.
 *
 * @author
 * @version HT 2019
 */
import java.util.Scanner;
import java.util.ArrayList;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.io.File;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

class SortComparison {

	/**
	 * Sorts an array of doubles using InsertionSort. This method is static, thus it
	 * can be called as SortComparison.sort(a)
	 * 
	 * @param a: An unsorted array of doubles.
	 * @return array sorted in ascending order.
	 *
	 */
	static double[] insertionSort(double a[]) {

		// todo: implement the sort
		if (a == null) {
			return null;
		}
		double temp;
		for (int i = 1; i < a.length; i++) {
			for (int j = i; j > 0; j--) {
				if (a[j] < a[j - 1]) {
					temp = a[j];
					a[j] = a[j - 1];
					a[j - 1] = temp;
				}
			}
		}
		return a;
	}// end insertionsort

	/**
	 * Sorts an array of doubles using Quick Sort. This method is static, thus it
	 * can be called as SortComparison.sort(a)
	 * 
	 * @param a: An unsorted array of doubles.
	 * @return array sorted in ascending order
	 *
	 */
	static double[] quickSort(double a[]) {

		// todo: implement the sort
		quickSortRecursive(a, 0, a.length - 1);
		return a;

	}// end quicksort

	static void quickSortRecursive(double a[], int lo, int hi) {
		if (hi <= lo) {
			return;
		}
		int pivotPos = quickSortPartition(a, lo, hi);
		quickSortRecursive(a, lo, pivotPos - 1);
		quickSortRecursive(a, pivotPos + 1, hi);

	}

	static int quickSortPartition(double[] a, int lo, int hi) {
		int x = lo;
		int j = hi + 1;
		Double pivot = a[lo];
		while (true) {
			while (Double.compare((a[++x]), pivot) < 0) {
				if (x == hi)
					break;
			}
			while ((pivot.compareTo(a[--j]) < 0)) {
				if (j == lo)
					break;
			}
			if (x >= j)
				break;
			double temp = a[x];
			a[x] = a[j];
			a[j] = temp;
		}
		a[lo] = a[j];
		a[j] = pivot;
		return j;
	}

	/**
	 * Sorts an array of doubles using Merge Sort. This method is static, thus it
	 * can be called as SortComparison.sort(a)
	 * 
	 * @param a: An unsorted array of doubles.
	 * @return array sorted in ascending order
	 *
	 */
	/**
	 * Sorts an array of doubles using iterative implementation of Merge Sort. This
	 * method is static, thus it can be called as SortComparison.sort(a)
	 *
	 * @param a: An unsorted array of doubles.
	 * @return after the method returns, the array must be in ascending sorted
	 *         order.
	 */

	static double[] mergeSortIterative(double a[]) {

		// todo: implement the sort
		/*
		 * if (a == null) { return a; } int midPos = a.length / 2; double[] left = new
		 * double[midPos]; for (int i = 0; i < midPos; i++) { left[i] = a[i]; }
		 * 
		 * double[] right = new double[a.length - midPos]; for (int j = midPos; j <
		 * a.length; j++) { right[j - midPos] = a[j]; } mergeSortIterative(left);
		 * mergeSortIterative(right);
		 * 
		 * int x = 0; int y = 0; int z = 0;
		 * 
		 * // Merge the left and right array while (x < left.length && y < right.length)
		 * { if (left[x] < right[y]) { a[z] = left[x]; x++; } else { a[z] = right[y];
		 * y++; } z++; } while (x < left.length) { a[z] = left[x]; x++; z++; } while (y
		 * < right.length) { a[z] = right[y]; y++; z++; }
		 * 
		 * return a;
		 */
		if (a == null) {
			return null;
		}

		if (a.length > 1) {
			int mid = a.length / 2;

			// Split left part
			double[] left = new double[mid];
			for (int i = 0; i < mid; i++) {
				left[i] = a[i];
			}

			// Split right part
			double[] right = new double[a.length - mid];
			for (int i = mid; i < a.length; i++) {
				right[i - mid] = a[i];
			}
			mergeSortIterative(left);
			mergeSortIterative(right);

			int i = 0;
			int j = 0;
			int k = 0;

			// Merge left and right arrays
			while (i < left.length && j < right.length) {
				if (left[i] < right[j]) {
					a[k] = left[i];
					i++;
				} else {
					a[k] = right[j];
					j++;
				}
				k++;
			}
			// Collect remaining elements
			while (i < left.length) {
				a[k] = left[i];
				i++;
				k++;
			}
			while (j < right.length) {
				a[k] = right[j];
				j++;
				k++;
			}

		}
		return a;

	}// end mergesortIterative

	/**
	 * Sorts an array of doubles using recursive implementation of Merge Sort. This
	 * method is static, thus it can be called as SortComparison.sort(a)
	 *
	 * @param a: An unsorted array of doubles.
	 * @return after the method returns, the array must be in ascending sorted
	 *         order.
	 */
	static double[] mergeSortRecursive(double a[]) {

		// todo: implement the sort
		double[] aux = new double[a.length];
		recursiveMethod(a, aux, 0, a.length - 1);
		return a;

	}// end mergeSortRecursive

	static void recursiveMethod(double a[], double aux[], int hi, int lo) {
		if (hi <= lo) {
			return;
		}
		int mid = lo + (hi - lo) / 2;
		recursiveMethod(a, aux, lo, mid);
		recursiveMethod(a, aux, mid + 1, hi);
		merge(a, aux, lo, mid, hi);

	}

	static void merge(double a[], double aux[], int lo, int mid, int hi) {
		/*
		 * for (int i = lo; i <= hi; i++) { aux[i] = a[i];
		 * 
		 * int j = lo; int k = mid + 1; for (i = lo; i <= hi; i++) { if (j > mid) { a[i]
		 * = aux[k++]; } else if (k > hi) { a[i] = aux[j++]; } else if ((aux[k] >
		 * aux[j])) { a[i] = aux[k++]; } else { a[i] = aux[j++]; } } }
		 */
		int i = lo;
		int j = mid + 1;
		for (int k = lo; k <= hi; k++) {
			if (i > mid) {
				aux[k] = a[j++];
			} else if (j > hi) {
				aux[k] = a[i++];
			} else if ((a[j] > a[i])) {
				aux[k] = a[j++];
			} else {
				a[k] = aux[i++];
			}
		}

	}

	/**
	 * Sorts an array of doubles using Selection Sort. This method is static, thus
	 * it can be called as SortComparison.sort(a)
	 * 
	 * @param a: An unsorted array of doubles.
	 * @return array sorted in ascending order
	 *
	 */
	static double[] selectionSort(double a[]) {

		// todo: implement the sort
		int size = a.length;

		for (int i = 0; i < size - 1; i++) {
			int min = i;
			for (int j = i + 1; j < size; j++) {
				if (a[j] < a[min]) {
					min = j;
				}
			}
			double temp = a[min];
			a[min] = a[i];
			a[i] = temp;
		}
		return a;

	}// end selectionsort

	public static void main(String[] args) throws InterruptedException {

		// todo: do experiments as per assignment instructions
		// Insertion Sort
		double[] data = readFiles("numbers10");
		double[] data2 = readFiles("numbers100");
		double[] data3 = readFiles("numbers1000");
		double[] data4 = readFiles("numbers1000Duplicates");
		double[] data5 = readFiles("numbersNearlyOrdered1000");
		double[] data6 = readFiles("numbersReverse1000");
		double[] data7 = readFiles("numbersSorted1000");
		// numbers10
		long startTime = System.currentTimeMillis();
		/* ... the code being measured starts ... */
		data = insertionSort(data);
		// sleep for 5 seconds
		TimeUnit.SECONDS.sleep(5);
		/* ... the code being measured ends ... */
		long endTime = System.currentTimeMillis();
		long timeElapsed = endTime - startTime;
		System.out.println("Execution of insertionSort with numbers10 time in milliseconds: " + timeElapsed);
		// numbers100
		long startTime2 = System.currentTimeMillis();
		data2 = insertionSort(data2);
		TimeUnit.SECONDS.sleep(5);
		long endTime2 = System.currentTimeMillis();
		long timeElapsed2 = endTime2 - startTime2;
		System.out.println("Execution of insertionSort with numbers100 time in milliseconds: " + timeElapsed2);
		// numbers1000
		long startTime3 = System.currentTimeMillis();
		data3 = insertionSort(data3);
		TimeUnit.SECONDS.sleep(5);
		long endTime3 = System.currentTimeMillis();
		long timeElapsed3 = endTime3 - startTime3;
		System.out.println("Execution of insertionSort with numbers1000 time in milliseconds: " + timeElapsed3);
		// numbers1000Duplicates
		long startTime4 = System.currentTimeMillis();
		data4 = insertionSort(data4);
		TimeUnit.SECONDS.sleep(5);
		long endTime4 = System.currentTimeMillis();
		long timeElapsed4 = endTime4 - startTime4;
		System.out
				.println("Execution of insertionSort with numbers1000Duplicates time in milliseconds: " + timeElapsed4);
		// numbersNearlyOrdered1000
		long startTime5 = System.currentTimeMillis();
		data5 = insertionSort(data5);
		TimeUnit.SECONDS.sleep(5);
		long endTime5 = System.currentTimeMillis();
		long timeElapsed5 = endTime5 - startTime5;
		System.out.println(
				"Execution of insertionSort with numbersNearlyOrdered1000 time in milliseconds: " + timeElapsed5);
		// numbersReverse1000
		long startTime6 = System.currentTimeMillis();
		data6 = insertionSort(data6);
		TimeUnit.SECONDS.sleep(5);
		long endTime6 = System.currentTimeMillis();
		long timeElapsed6 = endTime6 - startTime6;
		System.out.println("Execution of insertionSort with numbersReverse1000 time in milliseconds: " + timeElapsed6);
		// numbersSorted1000
		long startTime7 = System.currentTimeMillis();
		data7 = insertionSort(data7);
		TimeUnit.SECONDS.sleep(5);
		long endTime7 = System.currentTimeMillis();
		long timeElapsed7 = endTime7 - startTime7;
		System.out.println("Execution of insertionSort with numbersSorted1000 time in milliseconds: " + timeElapsed7);

		// QuickSort
		double[] dataQ1 = readFiles("numbers10");
		double[] dataQ2 = readFiles("numbers100");
		double[] dataQ3 = readFiles("numbers1000");
		double[] dataQ4 = readFiles("numbers1000Duplicates");
		double[] dataQ5 = readFiles("numbersNearlyOrdered1000");
		double[] dataQ6 = readFiles("numbersReverse1000");
		double[] dataQ7 = readFiles("numbersSorted1000");
		// numbers10
		long startTimeQ1 = System.currentTimeMillis();
		/* ... the code being measured starts ... */
		dataQ1 = quickSort(dataQ1);
		// sleep for 5 seconds
		TimeUnit.SECONDS.sleep(5);
		/* ... the code being measured ends ... */
		long endTimeQ1 = System.currentTimeMillis();
		long timeElapsedQ1 = endTimeQ1 - startTimeQ1;
		System.out.println("Execution of quickSort with numbers10 time in milliseconds: " + timeElapsedQ1);
		// numbers100
		long startTimeQ2 = System.currentTimeMillis();
		dataQ2 = quickSort(dataQ2);
		TimeUnit.SECONDS.sleep(5);
		long endTimeQ2 = System.currentTimeMillis();
		long timeElapsedQ2 = endTimeQ2 - startTimeQ2;
		System.out.println("Execution of quickSort with numbers100 time in milliseconds: " + timeElapsedQ2);
		// numbers1000
		long startTimeQ3 = System.currentTimeMillis();
		dataQ3 = quickSort(dataQ3);
		TimeUnit.SECONDS.sleep(5);
		long endTimeQ3 = System.currentTimeMillis();
		long timeElapsedQ3 = endTimeQ3 - startTimeQ3;
		System.out.println("Execution of quickSort with numbers1000 time in milliseconds: " + timeElapsedQ3);
		// numbers1000Duplicates
		long startTimeQ4 = System.currentTimeMillis();
		dataQ4 = quickSort(dataQ4);
		TimeUnit.SECONDS.sleep(5);
		long endTimeQ4 = System.currentTimeMillis();
		long timeElapsedQ4 = endTimeQ4 - startTimeQ4;
		System.out.println("Execution of quickSort with numbers1000Duplicates time in milliseconds: " + timeElapsedQ4);
		// numbersNearlyOrdered1000
		long startTimeQ5 = System.currentTimeMillis();
		dataQ5 = quickSort(data5);
		TimeUnit.SECONDS.sleep(5);
		long endTimeQ5 = System.currentTimeMillis();
		long timeElapsedQ5 = endTimeQ5 - startTimeQ5;
		System.out
				.println("Execution of quickSort with numbersNearlyOrdered1000 time in milliseconds: " + timeElapsedQ5);
		// numbersReverse1000
		long startTimeQ6 = System.currentTimeMillis();
		dataQ6 = quickSort(dataQ6);
		TimeUnit.SECONDS.sleep(5);
		long endTimeQ6 = System.currentTimeMillis();
		long timeElapsedQ6 = endTimeQ6 - startTimeQ6;
		System.out.println("Execution of quickSort with numbersReverse1000 time in milliseconds: " + timeElapsedQ6);
		// numbersSorted1000
		long startTimeQ7 = System.currentTimeMillis();
		dataQ7 = quickSort(dataQ7);
		TimeUnit.SECONDS.sleep(5);
		long endTimeQ7 = System.currentTimeMillis();
		long timeElapsedQ7 = endTimeQ7 - startTimeQ7;
		System.out.println("Execution of quickSort with numbersSorted1000 time in milliseconds: " + timeElapsedQ7);

		// Selection Sort
		double[] dataS1 = readFiles("numbers10");
		double[] dataS2 = readFiles("numbers100");
		double[] dataS3 = readFiles("numbers1000");
		double[] dataS4 = readFiles("numbers1000Duplicates");
		double[] dataS5 = readFiles("numbersNearlyOrdered1000");
		double[] dataS6 = readFiles("numbersReverse1000");
		double[] dataS7 = readFiles("numbersSorted1000");
		// numbers10
		long startTimeS1 = System.currentTimeMillis();
		/* ... the code being measured starts ... */
		dataS1 = selectionSort(dataS1);
		// sleep for 5 seconds
		TimeUnit.SECONDS.sleep(5);
		/* ... the code being measured ends ... */
		long endTimeS1 = System.currentTimeMillis();
		long timeElapsedS1 = endTimeS1 - startTimeS1;
		System.out.println("Execution of selectionSort with numbers10 time in milliseconds: " + timeElapsedS1);
		// numbers100
		long startTimeS2 = System.currentTimeMillis();
		dataS2 = selectionSort(dataS2);
		TimeUnit.SECONDS.sleep(5);
		long endTimeS2 = System.currentTimeMillis();
		long timeElapsedS2 = endTimeS2 - startTimeS2;
		System.out.println("Execution of selectionSort with numbers100 time in milliseconds: " + timeElapsedS2);
		// numbers1000
		long startTimeS3 = System.currentTimeMillis();
		dataS3 = selectionSort(dataS3);
		TimeUnit.SECONDS.sleep(5);
		long endTimeS3 = System.currentTimeMillis();
		long timeElapsedS3 = endTimeS3 - startTimeS3;
		System.out.println("Execution of selectionSort with numbers1000 time in milliseconds: " + timeElapsedS3);
		// numbers1000Duplicates
		long startTimeS4 = System.currentTimeMillis();
		dataS4 = selectionSort(dataS4);
		TimeUnit.SECONDS.sleep(5);
		long endTimeS4 = System.currentTimeMillis();
		long timeElapsedS4 = endTimeS4 - startTimeS4;
		System.out.println(
				"Execution of selectionSort with numbers1000Duplicates time in milliseconds: " + timeElapsedS4);
		// numbersNearlyOrdered1000
		long startTimeS5 = System.currentTimeMillis();
		dataS5 = selectionSort(dataS5);
		TimeUnit.SECONDS.sleep(5);
		long endTimeS5 = System.currentTimeMillis();
		long timeElapsedS5 = endTimeS5 - startTimeS5;
		System.out.println(
				"Execution of selectionSort with numbersNearlyOrdered1000 time in milliseconds: " + timeElapsedS5);
		// numbersReverse1000
		long startTimeS6 = System.currentTimeMillis();
		dataS6 = selectionSort(dataS6);
		TimeUnit.SECONDS.sleep(5);
		long endTimeS6 = System.currentTimeMillis();
		long timeElapsedS6 = endTimeS6 - startTimeS6;
		System.out.println("Execution of selectionSort with numbersReverse1000 time in milliseconds: " + timeElapsedS6);
		// numbersSorted1000
		long startTimeS7 = System.currentTimeMillis();
		dataS7 = selectionSort(dataS7);
		TimeUnit.SECONDS.sleep(5);
		long endTimeS7 = System.currentTimeMillis();
		long timeElapsedS7 = endTimeS7 - startTimeS7;
		System.out.println("Execution of selectionSort with numbersSorted1000 time in milliseconds: " + timeElapsedS7);

		// mergeSortIterative
		double[] dataM1 = readFiles("numbers10");
		double[] dataM2 = readFiles("numbers100");
		double[] dataM3 = readFiles("numbers1000");
		double[] dataM4 = readFiles("numbers1000Duplicates");
		double[] dataM5 = readFiles("numbersNearlyOrdered1000");
		double[] dataM6 = readFiles("numbersReverse1000");
		double[] dataM7 = readFiles("numbersSorted1000");
		// numbers10
		long startTimeM1 = System.currentTimeMillis();
		/* ... the code being measured starts ... */
		dataM1 = mergeSortIterative(dataM1);
		// sleep for 5 seconds
		TimeUnit.SECONDS.sleep(5);
		/* ... the code being measured ends ... */
		long endTimeM1 = System.currentTimeMillis();
		long timeElapsedM1 = endTimeM1 - startTimeM1;
		System.out.println("Execution of mergeSortIterative with numbers10 time in milliseconds: " + timeElapsedM1);
		// numbers100
		long startTimeM2 = System.currentTimeMillis();
		dataM2 = mergeSortIterative(dataM2);
		TimeUnit.SECONDS.sleep(5);
		long endTimeM2 = System.currentTimeMillis();
		long timeElapsedM2 = endTimeM2 - startTimeM2;
		System.out.println("Execution of mergeSortIterative with numbers100 time in milliseconds: " + timeElapsedM2);
		// numbers1000
		long startTimeM3 = System.currentTimeMillis();
		dataM3 = mergeSortIterative(dataM3);
		TimeUnit.SECONDS.sleep(5);
		long endTimeM3 = System.currentTimeMillis();
		long timeElapsedM3 = endTimeM3 - startTimeM3;
		System.out.println("Execution of mergeSortIterative with numbers1000 time in milliseconds: " + timeElapsedM3);
		// numbers1000Duplicates
		long startTimeM4 = System.currentTimeMillis();
		dataM4 = mergeSortIterative(dataM4);
		TimeUnit.SECONDS.sleep(5);
		long endTimeM4 = System.currentTimeMillis();
		long timeElapsedM4 = endTimeM4 - startTimeM4;
		System.out.println(
				"Execution of mergeSortIterative with numbers1000Duplicates time in milliseconds: " + timeElapsedM4);
		// numbersNearlyOrdered1000
		long startTimeM5 = System.currentTimeMillis();
		dataM5 = mergeSortIterative(dataM5);
		TimeUnit.SECONDS.sleep(5);
		long endTimeM5 = System.currentTimeMillis();
		long timeElapsedM5 = endTimeM5 - startTimeM5;
		System.out.println(
				"Execution of mergeSortIterative with numbersNearlyOrdered1000 time in milliseconds: " + timeElapsedM5);
		// numbersReverse1000
		long startTimeM6 = System.currentTimeMillis();
		dataM6 = mergeSortIterative(dataM6);
		TimeUnit.SECONDS.sleep(5);
		long endTimeM6 = System.currentTimeMillis();
		long timeElapsedM6 = endTimeM6 - startTimeM6;
		System.out.println(
				"Execution of mergeSortIterative with numbersReverse1000 time in milliseconds: " + timeElapsedM6);
		// numbersSorted1000
		long startTimeM7 = System.currentTimeMillis();
		dataM7 = mergeSortIterative(dataM7);
		TimeUnit.SECONDS.sleep(5);
		long endTimeM7 = System.currentTimeMillis();
		long timeElapsedM7 = endTimeM7 - startTimeM7;
		System.out.println(
				"Execution of mergeSortIterative with numbersSorted1000 time in milliseconds: " + timeElapsedM7);

		// mergeSortRecursive
		double[] dataR1 = readFiles("numbers10");
		dataR1 = mergeSortRecursive(dataR1);
		for (int i = 0; i < dataR1.length; i++) {
			System.out.println(dataR1[i]);
		}
	}

	public static double[] readFiles(String file) {
		try {
			File f = new File(file);
			Scanner scanner = new Scanner(f);
			int counter = 0;
			while (scanner.hasNextDouble()) {
				counter++;
				scanner.nextDouble();
			}
			double[] numbers = new double[counter];
			Scanner scanner2 = new Scanner(f);

			for (int i = 0; i < numbers.length; i++) {
				numbers[i] = scanner2.nextDouble();
			}

			return numbers;
		} catch (Exception e) {
			return null;
		}
	}

}// end class
