import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import java.util.Arrays;

import junit.framework.Assert;

//-------------------------------------------------------------------------
/**
 * Test class for SortComparison.java
 *
 * @author
 * @version HT 2019
 */
public class SortComparisonTest {

	// ~ Constructor ........................................................
	@Test
	public void testConstructor() {
		new SortComparison();
	}

	// ~ Public Methods ........................................................

	// ----------------------------------------------------------
	/**
	 * Check that the methods work for empty arrays
	 */
	@Test
	public void testEmpty() {
		double[] testArray = {};
		double[] expectedArray = {};
		testArray = SortComparison.insertionSort(testArray);
		assertTrue(Arrays.equals(expectedArray, testArray));

	}

	// TODO: add more tests here. Each line of code and ech decision in
	// Collinear.java should
	// be executed at least once from at least one test.

	// ----------------------------------------------------------
	/**
	 * Main Method. Use this main method to create the experiments needed to answer
	 * the experimental performance questions of this assignment.
	 *
	 */
	public static void main(String[] args) {
		// TODO: implement this method
	}

	@Test
	public void testInsertionSort() {
		double[] testArray = { 6.0, 7.0, 10.0, 3.0, 21.0, 5.0 };
		double[] expectedArray = { 3.0, 5.0, 6.0, 7.0, 10.0, 21.0 };
		testArray = SortComparison.insertionSort(testArray);
		assertTrue(Arrays.equals(expectedArray, testArray));

	}

	@Test
	public void testQuickSort() {
		double[] testArray = { 6.0, 7.0, 10.0, 3.0, 21.0, 5.0 };
		double[] expectedArray = { 3.0, 5.0, 6.0, 7.0, 10.0, 21.0 };
		testArray = SortComparison.quickSort(testArray);
		assertTrue(Arrays.equals(expectedArray, testArray));
	}

	@Test
	public void testMergeSortIterative() {
		double[] testArray = { 6.0, 7.0, 10.0, 3.0, 21.0, 5.0 };
		double[] expectedArray = { 3.0, 5.0, 6.0, 7.0, 10.0, 21.0 };
		testArray = SortComparison.mergeSortIterative(testArray);
		assertTrue(Arrays.equals(expectedArray, testArray));
	}

	@Test
	public void testMergeSortRecursive() {
		fail("Not yet implemented");
	}

	@Test
	public void testSelectionSort() {
		double[] testArray = { 6.0, 7.0, 10.0, 3.0, 21.0, 5.0 };
		double[] expectedArray = { 3.0, 5.0, 6.0, 7.0, 10.0, 21.0 };
		testArray = SortComparison.selectionSort(testArray);
		assertTrue(Arrays.equals(expectedArray, testArray));
	}

	@Test
	public void testMain() {
		fail("Not yet implemented");
	}

}
