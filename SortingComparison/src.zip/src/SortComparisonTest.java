import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

//-------------------------------------------------------------------------
/**
*  Test class for SortComparison.java
*
*  @author
*  @version HT 2019
*/
public class SortComparisonTest {
	
	 //~ Constructor ........................................................
    @Test
    public void testConstructor()
    {
        new SortComparison();
    }

    //~ Public Methods ........................................................

    // ----------------------------------------------------------
    /**
     * Check that the methods work for empty arrays
     */
    @Test
    public void testEmpty()
    {
    	
    }


    // TODO: add more tests here. Each line of code and ech decision in Collinear.java should
    // be executed at least once from at least one test.

    // ----------------------------------------------------------
    /**
     *  Main Method.
     *  Use this main method to create the experiments needed to answer the experimental performance questions of this assignment.
     *
     */
    public static void main(String[] args)
    {
        //TODO: implement this method
    }

	@Test
	public void testInsertionSort() {
		double[] testArray = new double[]{ };
    	testArray = insertionSort(testArray);
	}

	@Test
	public void testQuickSort() {
		fail("Not yet implemented");
	}

	@Test
	public void testMergeSortIterative() {
		fail("Not yet implemented");
	}

	@Test
	public void testMergeSortRecursive() {
		fail("Not yet implemented");
	}

	@Test
	public void testSelectionSort() {
		fail("Not yet implemented");
	}

	@Test
	public void testMain() {
		fail("Not yet implemented");
	}

}
